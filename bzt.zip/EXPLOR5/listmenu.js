const listmenu = (prefix) => { 
	return ` *LIST MENU 3XPLOR5.7 BOT*
	
	
╭─「 *MEDIA DOWNLOADER* 」──
├➲ *${prefix}tiktokstalk [username]*
├➲ *${prefix}igstalk [username]*
├➲ *${prefix}insta [Link]*
├➲ *${prefix}instastory [username]*
├➲ *${prefix}ssweb [url]*
├➲ *${prefix}url2img [Url]*
├➲ *${prefix}tiktok*
├➲ *${prefix}fototiktok*
├➲ *${prefix}meme*
├➲ *${prefix}memeindo*
├➲ *${prefix}kbbi*
├➲ *${prefix}wait*
├➲ *${prefix}trendtwit*
├➲ *${prefix}google [berita terkini]*
├➲ *${prefix}pinterest*
├➲ *${prefix}play*
╰─────────────────────

╭────「 *FUN & GAME* 」────
├➲ *${prefix}anjing*
├➲ *${prefix}kucing*
├➲ *${prefix}testime*
├➲ *${prefix}hilih*
├➲ *${prefix}say*
├➲ *${prefix}apakah*
├➲ *${prefix}kapankah*
├➲ *${prefix}bisakah*
├➲ *${prefix}rate*
├➲ *${prefix}watak*
├➲ *${prefix}hobby*
├➲ *${prefix}infogempa*
├➲ *${prefix}infonomor*
├➲ *${prefix}quotes*
├➲ *${prefix}truth*
├➲ *${prefix}dare*
├➲ *${prefix}katabijak*
├➲ *${prefix}fakta*
├➲ *${prefix}darkjokes*
├➲ *${prefix}bucin*
├➲ *${prefix}pantun*
├➲ *${prefix}katacinta*
├➲ *${prefix}jadwaltvnow*
├➲ *${prefix}hekerbucin*
├➲ *${prefix}katailham*
├➲ *${prefix}caklontong*
├➲ *${prefix}family100*
╰─────────────────────


╭─────────────────────
├➲ *${prefix}asupan*
├➲ *${prefix}tebakgambar*
├➲ *${prefix}caklontong*
├➲ *${prefix}family100*
├➲ *${prefix}kalkulator [13*12]*
├➲ *${prefix}wp [gunung]*
╰─────────────────────


╭───「 *OTHER & DEFACE* 」───
├➲ *${prefix}jarak [Klatem/Jogja]*
├➲ *${prefix}translate [en/Apa kabar?]*
├➲ *${prefix}pasangan [nama lu/nama cewe lu]*
├➲ *${prefix}gantengcek [username]*
├➲ *${prefix}cantikcek [Salsa]*
├➲ *${prefix}artinama [username]*
├➲ *${prefix}persengay [username]*
├➲ *${prefix}pbucin [username]*
├➲ *${prefix}bpfont [username]*
├➲ *${prefix}textstyle [username Graphy]*
├➲ *${prefix}jadwaltv [GTV]*
├➲ *${prefix}lirik [I am lady]*
├➲ *${prefix}chord [I am lady]*
├➲ *${prefix}wiki [Adolf Hitler]*
├➲ *${prefix}brainly [pertanyaan]*
├➲ *${prefix}resepmasakan [rawon]*
├➲ *${prefix}map [Klaten]*
├➲ *${prefix}film [The Walking Death]*
├➲ *${prefix}pinterest [gambar kucing]*
├➲ *${prefix}infocuaca [Klaten]*
├➲ *${prefix}jamdunia [Indonesia]*
├➲ *${prefix}mimpi [Bersamanya]*
├➲ *${prefix}infoalamat [jalan Klaten]*
╰─────────────────────


╭─────────────────────
├➲ *${prefix}asupan*
├➲ *${prefix}tebakgambar*
├➲ *${prefix}caklontong*
├➲ *${prefix}family100*
├➲ *${prefix}kalkulator [13*12]*
├➲ *${prefix}wp [gunung]*
╰─────────────────────

╭─────────────────────
├➲ *${prefix}jadwalsholat [Klaten]*
├➲ *${prefix}quran*
├➲ *${prefix}quransurah [1]*
├➲ *${prefix}tafsir [1/5]*
╰─────────────────────

╭─────────────────────
├➲ *${prefix}becrypt [string]*
├➲ *${prefix}encode64 [string]*
├➲ *${prefix}decode64 [encrypt]*
├➲ *${prefix}encode32 [string]*
├➲ *${prefix}decode32 [encrypt]*
├➲ *${prefix}encbinary [string]*
├➲ *${prefix}decbinary [encrypt]*
├➲ *${prefix}encoctal [string]*
├➲ *${prefix}decoctal [encrypt]*
├➲ *${prefix}hashidentifier [Encrypt Hash]*
├➲ *${prefix}dorking [dork]*
├➲ *${prefix}pastebin [teks]*
├➲ *${prefix}tinyurl [link]*
├➲ *${prefix}bitly [link]*
╰─────────────────────

╭───「 *CREATOR MENU* 」───
├➲ *${prefix}sticker*
├➲ *${prefix}quotemaker [tx/wtrmk/tema]*
├➲ *${prefix}nulis [nama/kelas/text]*
├➲ *${prefix}trigger [reply image]*
├➲ *${prefix}rip [reply image]*
├➲ *${prefix}wasted [reply image]*
├➲ *${prefix}cphlogo [username]*
├➲ *${prefix}cglitch [Fadhil/Graphy]*
├➲ *${prefix}cpubg [username]*
├➲ *${prefix}cml [username]*
├➲ *${prefix}tahta [username]*
├➲ *${prefix}croman [lu dan nama target]*
├➲ *${prefix}cthunder [username]*
├➲ *${prefix}cbpink [username]*
├➲ *${prefix}cmwolf [username]*
├➲ *${prefix}csky [username]*
├➲ *${prefix}cwooden [username]*
├➲ *${prefix}cflower [username]*
├➲ *${prefix}clove [username]*
├➲ *${prefix}ccrossfire [username]*
├➲ *${prefix}cnaruto [username]*
├➲ *${prefix}cparty [username]*
├➲ *${prefix}cshadow [username]*
├➲ *${prefix}cminion [username]*
├➲ *${prefix}cneon [username]*
├➲ *${prefix}cneon2 [username]*
├➲ *${prefix}cneongreen [username]*
├➲ *${prefix}c3d [username]*
├➲ *${prefix}csky [username]*
├➲ *${prefix}tts [id Haii]*
├➲ *${prefix}ttp [username]*
├➲ *${prefix}slide [username]*
├➲ *${prefix}stiker*
├➲ *${prefix}gifstiker*
├➲ *${prefix}toimg*
├➲ *${prefix}img2url*
├➲ *${prefix}nobg*
├➲ *${prefix}tomp3*
├➲ *${prefix}ocr*
╰──────────────────────

╭──────「 *GROUP ONLY* 」───
├➲ *${prefix}modeanime [On/Off]*
├➲ *${prefix}naruto*
├➲ *${prefix}minato*
├➲ *${prefix}boruto*
├➲ *${prefix}hinata*
├➲ *${prefix}sakura*
├➲ *${prefix}sasuke*
├➲ *${prefix}kaneki*
├➲ *${prefix}toukachan*
├➲ *${prefix}rize*
├➲ *${prefix}akira*
├➲ *${prefix}itori*
├➲ *${prefix}kurumi*
├➲ *${prefix}miku*
├➲ *${prefix}anime*
├➲ *${prefix}animecry*
├➲ *${prefix}neonime*
├➲ *${prefix}animekiss*
├➲ *${prefix}wink*
╰─────────────────────

╭─────────────────────
├➲ *${prefix}welcome [On/Off]*
├➲ *${prefix}grup [buka/tutup]*
├➲ *${prefix}antilink [on/off*
├➲ *${prefix}ownergrup*
├➲ *${prefix}setpp*
├➲ *${prefix}infogc*
├➲ *${prefix}add*
├➲ *${prefix}kick*
├➲ *${prefix}promote*
├➲ *${prefix}demote*
├➲ *${prefix}setname*
├➲ *${prefix}setdesc*
├➲ *${prefix}linkgrup*
├➲ *${prefix}tagme*
├➲ *${prefix}hidetag*
├➲ *${prefix}tagall*
├➲ *${prefix}mentionall*
├➲ *${prefix}fitnah*
├➲ *${prefix}listadmin*
├➲ *${prefix}openanime*
├➲ *${prefix}edotense*
╰──────────────────────

╭──────────────────────
├➲ *${prefix}nsfw [On/Off]*
├➲ *${prefix}nsfwloli*
├➲ *${prefix}nsfwblowjob*
├➲ *${prefix}nsfwneko*
├➲ *${prefix}nsfwtrap*
├➲ *${prefix}hentai*
├➲ *${prefix}simih [On/Off]*
╰──────────────────────

╭────「 *OWNER ONLY* 」─────
├➲ *${prefix}addprem [mentioned]*
├➲ *${prefix}removeprem [mention]*
├➲ *${prefix}setppbot*
├➲ *${prefix}setreply*
├➲ *${prefix}bc*
├➲ *${prefix}bcgc*
├➲ *${prefix}ban*
├➲ *${prefix}unban*
├➲ *${prefix}block*
├➲ *${prefix}unblock*
├➲ *${prefix}clearall*
├➲ *${prefix}delete*
├➲ *${prefix}clone*
├➲ *${prefix}getses*
├➲ *${prefix}leave*
╰──────────────────────


╭─────「 *PREMIUM ONLY* 」───
├➲ *${prefix}playmp3 [I am Lady]*
├➲ *${prefix}fb [link video]*
├➲ *${prefix}snack [link snack video]*
├➲ *${prefix}ytmp3 [link yt]*
├➲ *${prefix}ytmp4 [link yt]*
├➲ *${prefix}joox [Monolog Pamungkas]*
├➲ *${prefix}smule [Link Video Smule]*
├➲ *${prefix}cersex*
├➲ *${prefix}asupan*
├➲ *${prefix}xxx [japan]*
├➲ *${prefix}pornhub [GangBang]*
├➲ *${prefix}hentai [Random]*
├➲ *${prefix}ban [TagUser]*
├➲ *${prefix}unban [TagUser]*
├➲ *${prefix}bc [teks]*
├➲ *${prefix}asupan*
╰──────────────────────

	
               *©explors*`
	}
exports.listmenu = listmenu